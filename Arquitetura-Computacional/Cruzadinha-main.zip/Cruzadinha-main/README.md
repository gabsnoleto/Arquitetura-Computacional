# Cruzadinha
Cruzadinha solicitada pelo professor de Arquitetura Computacional
